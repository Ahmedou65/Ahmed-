import { useEffect, useRef, useState } from 'react';
import { 
  Waves, 
  Landmark, 
  Church, 
  Factory, 
  Users, 
  Leaf, 
  Droplets, 
  Shovel,
  ArrowDown,
  MapPin,
  Clock,
  BookOpen,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

// Hook per animazioni al scroll
function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.15 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return { ref, isVisible };
}

// Componente Section
function Section({ 
  id, 
  title, 
  subtitle, 
  children, 
  className = '',
  bgGradient = 'earth'
}: { 
  id: string; 
  title: string; 
  subtitle?: string; 
  children: React.ReactNode; 
  className?: string;
  bgGradient?: 'earth' | 'water' | 'none';
}) {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section 
      id={id}
      className={`min-h-screen py-20 px-4 md:px-8 lg:px-16 relative ${
        bgGradient === 'earth' ? 'earth-gradient' : bgGradient === 'water' ? 'water-gradient' : ''
      } ${className}`}
    >
      <div 
        ref={ref}
        className={`max-w-6xl mx-auto ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}
      >
        <div className="text-center mb-16">
          {subtitle && (
            <span className="text-sabbia text-sm font-semibold tracking-widest uppercase mb-4 block">
              {subtitle}
            </span>
          )}
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-papiro mb-6">
            {title}
          </h2>
          <div className="section-divider w-32 mx-auto" />
        </div>
        {children}
      </div>
    </section>
  );
}

// Componente FeatureCard
function FeatureCard({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ElementType; 
  title: string; 
  description: string;
}) {
  return (
    <Card className="bg-card/80 backdrop-blur-sm border-terra/30 hover:border-terra transition-all duration-300 hover:transform hover:-translate-y-1">
      <CardContent className="p-6">
        <div className="w-12 h-12 rounded-lg bg-terra/20 flex items-center justify-center mb-4">
          <Icon className="w-6 h-6 text-sabbia" />
        </div>
        <h4 className="text-lg font-semibold text-papiro mb-2">{title}</h4>
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
}

// Hero Section
function Hero() {
  const scrollToContent = () => {
    document.getElementById('antichita')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen relative flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-notte via-[#2a2018] to-notte" />
      
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-terra blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-acqua blur-3xl" />
      </div>
      
      {/* Water waves effect */}
      <div className="absolute bottom-0 left-0 right-0 h-32 opacity-20">
        <svg viewBox="0 0 1440 120" className="w-full h-full" preserveAspectRatio="none">
          <path 
            fill="currentColor" 
            className="text-acqua"
            d="M0,64 C480,128 960,0 1440,64 L1440,120 L0,120 Z"
          />
        </svg>
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-terra/20 border border-terra/30">
          <Clock className="w-4 h-4 text-sabbia" />
          <span className="text-sabbia text-sm font-medium">Dagli albori alla modernità</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-papiro mb-6 text-shadow-lg">
          La Storia della
          <span className="block text-sabbia mt-2">Bonifica</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed">
          Dal dominio delle acque all'equilibrio con la natura: 
          un viaggio attraverso i secoli della trasformazione del territorio italiano
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-lg border border-border">
            <Landmark className="w-5 h-5 text-terra" />
            <span className="text-sm">Antichità</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-lg border border-border">
            <Church className="w-5 h-5 text-sabbia" />
            <span className="text-sm">Medioevo</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-lg border border-border">
            <Factory className="w-5 h-5 text-acqua" />
            <span className="text-sm">Età Moderna</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-card/50 rounded-lg border border-border">
            <Leaf className="w-5 h-5 text-green-500" />
            <span className="text-sm">Oggi</span>
          </div>
        </div>
        
        <Button 
          onClick={scrollToContent}
          size="lg"
          className="bg-terra hover:bg-terra/80 text-papiro px-8 py-6 text-lg rounded-full"
        >
          Inizia il viaggio
          <ArrowDown className="ml-2 w-5 h-5 animate-bounce" />
        </Button>
      </div>
    </section>
  );
}

// Antichità Section
function AntichitaSection() {
  const features = [
    { icon: Waves, title: "Canali di drenaggio", description: "Sistema di canalizzazione per deviare le acque e bonificare le terre" },
    { icon: Shovel, title: "Argini", description: "Costruzioni per contenere i fiumi e prevenire le inondazioni" },
    { icon: Droplets, title: "Fogne", description: "La celebre Cloaca Maxima a Roma, capolavoro di ingegneria" },
  ];

  const purposes = [
    "Espandere l'agricoltura",
    "Fondare città",
    "Controllare le acque e prevenire malattie"
  ];

  return (
    <Section id="antichita" title="I Romani, Maestri d'Acqua" subtitle="Antichità">
      {/* Immagine centrale */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-terra/30 shadow-2xl">
        <img 
          src="/images/romani-centuriazione.jpg" 
          alt="Centuriazione romana"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">La centuriazione romana: il primo sistema organizzato di bonifica</p>
        </div>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <p className="text-lg leading-relaxed mb-6">
            I primi grandi esperti di bonifica furono i <strong className="text-sabbia">Romani</strong>. 
            Con la loro ingegneria avanzata, trasformarono intere regioni, convertendo paludi 
            malsane in terre fertili e fondando città che durano ancora oggi.
          </p>
          <p className="text-lg leading-relaxed mb-8">
            Le loro opere idrauliche erano così ben progettate che alcune zone bonificate, 
            come parti della <strong>Pianura Padana</strong>, rimasero produttive per secoli 
            dopo la caduta dell'Impero.
          </p>
          
          <div className="bg-card/50 rounded-lg p-6 border border-terra/30">
            <h4 className="text-sabbia font-semibold mb-4 flex items-center gap-2">
              <ChevronRight className="w-5 h-5" />
              Obiettivi della bonifica romana
            </h4>
            <ul className="space-y-3">
              {purposes.map((purpose, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-terra mt-2 flex-shrink-0" />
                  <span>{purpose}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="grid gap-4">
          {features.map((feature, idx) => (
            <FeatureCard 
              key={idx}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-terra/10 to-acqua/10 rounded-xl p-8 border border-terra/20">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-terra flex items-center justify-center flex-shrink-0">
            <Landmark className="w-6 h-6 text-papiro" />
          </div>
          <div>
            <h4 className="text-xl font-semibold text-papiro mb-2">La Cloaca Maxima</h4>
            <p className="text-muted-foreground leading-relaxed">
              Il sistema fognario più antico e famoso di Roma, costruito intorno al 600 a.C. 
              per drenare le acque stagnanti della valle tra i colli. Ancora oggi funziona, 
              dimostrando la genialità dell'ingegneria romana.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

// Medioevo Section
function MedioevoSection() {
  return (
    <Section id="medioevo" title="Un Passo Indietro" subtitle="Medioevo" bgGradient="water">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-acqua/30 shadow-2xl">
        <img 
          src="/images/medioevo-monastero.jpg" 
          alt="Monastero medievale e bonifica"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">I monasteri mantennero vive le tecniche di bonifica nel Medioevo</p>
        </div>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="order-2 lg:order-1">
          <div className="relative">
            <div className="absolute inset-0 bg-acqua/20 rounded-2xl transform rotate-3" />
            <div className="relative bg-card rounded-2xl p-8 border border-acqua/30">
              <Church className="w-16 h-16 text-acqua mb-6" />
              <h4 className="text-2xl font-semibold text-papiro mb-4">Le Eccezioni</h4>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Non tutto era perduto: <strong className="text-sabbia">monasteri</strong> e 
                <strong className="text-sabbia"> comunità locali</strong> continuarono piccole 
                bonifiche per sopravvivere, specialmente nel Nord Italia.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Questi insediamenti mantennero vive le tecniche idrauliche, 
                preservando il sapere per le generazioni future.
              </p>
            </div>
          </div>
        </div>
        
        <div className="order-1 lg:order-2">
          <p className="text-lg leading-relaxed mb-6">
            Dopo la caduta dell'Impero Romano, molte opere idrauliche furono 
            <strong className="text-acqua"> abbandonate</strong>. La manutenzione cessò, 
            e la natura riprese il sopravvento.
          </p>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-4 p-4 bg-card/50 rounded-lg border border-border">
              <Waves className="w-8 h-8 text-acqua" />
              <div>
                <span className="font-semibold text-papiro">Paludi</span>
                <p className="text-sm text-muted-foreground">Le zone umide tornarono a espandersi</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-card/50 rounded-lg border border-border">
              <Droplets className="w-8 h-8 text-acqua" />
              <div>
                <span className="font-semibold text-papiro">Allagamenti</span>
                <p className="text-sm text-muted-foreground">I fiumi strariparono senza controllo</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-card/50 rounded-lg border border-border">
              <Users className="w-8 h-8 text-acqua" />
              <div>
                <span className="font-semibold text-papiro">Malaria</span>
                <p className="text-sm text-muted-foreground">Le malattie tornarono a diffondersi</p>
              </div>
            </div>
          </div>
          
          <p className="text-lg leading-relaxed">
            Il territorio italiano, un tempo dominato dall'uomo, 
            tornò parzialmente allo stato selvaggio.
          </p>
        </div>
      </div>
    </Section>
  );
}

// Età Moderna Section
function EtaModernaSection() {
  const developments = [
    { title: "Conoscenze tecniche", desc: "Migliorano le tecniche di drenaggio e canalizzazione" },
    { title: "Grandi opere", desc: "In Veneto, Emilia e Toscana nascono imponenti sistemi idraulici" },
    { title: "Sviluppo agricolo", desc: "La bonifica diventa strumento di crescita economica" },
    { title: "Controllo territoriale", desc: "Aumento della ricchezza e del dominio sul territorio" },
  ];

  return (
    <Section id="eta-moderna" title="Tecnica e Agricoltura" subtitle="Età Moderna">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-terra/30 shadow-2xl">
        <img 
          src="/images/eta-moderna.jpg" 
          alt="Ingegneri del Rinascimento"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">Ingegneri rinascimentali progettano nuove opere idrauliche</p>
        </div>
      </div>
      
      <p className="text-xl text-center text-muted-foreground max-w-3xl mx-auto mb-12">
        Tra Rinascimento e Settecento, la bonifica riprende slancio 
        con nuove conoscenze e ambizioni.
      </p>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        {developments.map((dev, idx) => (
          <Card key={idx} className="bg-card/80 border-terra/30 hover:border-terra transition-all">
            <CardContent className="p-6">
              <div className="w-10 h-10 rounded-full bg-terra/20 flex items-center justify-center mb-4">
                <span className="text-sabbia font-bold">{idx + 1}</span>
              </div>
              <h4 className="font-semibold text-papiro mb-2">{dev.title}</h4>
              <p className="text-sm text-muted-foreground">{dev.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="bg-gradient-to-br from-terra/20 to-sabbia/10 rounded-xl p-8">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-24 h-24 rounded-full bg-terra flex items-center justify-center flex-shrink-0">
            <BookOpen className="w-12 h-12 text-papiro" />
          </div>
          <div>
            <h4 className="text-2xl font-semibold text-papiro mb-4">Un Nuovo Approccio</h4>
            <p className="text-muted-foreground leading-relaxed text-lg">
              In questo periodo la bonifica non è più solo necessità, ma diventa 
              <strong className="text-sabbia"> progetto di sviluppo</strong>. 
              Signori e signorie investono nelle opere idrauliche per aumentare 
              la produzione agricola e consolidare il proprio potere.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

// Ottocento Novecento Section
function OttocentoNovecentoSection() {
  const innovations = [
    { icon: Factory, title: "Pompe meccaniche", desc: "La rivoluzione industriale porta macchinari potenti" },
    { icon: Waves, title: "Grandi canali", desc: "Opere su scala mai vista prima" },
    { icon: MapPin, title: "Interventi nazionali", desc: "La bonifica diventa affare di Stato" },
  ];

  return (
    <Section id="ottocento-novecento" title="La Bonifica Moderna" subtitle="Ottocento e Novecento" bgGradient="water">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-acqua/30 shadow-2xl">
        <img 
          src="/images/ottocento-industriale.jpg" 
          alt="Pompe a vapore nell'Ottocento"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">Le pompe a vapore rivoluzionano la bonifica nell'Ottocento</p>
        </div>
      </div>
      
      <div className="grid lg:grid-cols-3 gap-8 mb-16">
        {innovations.map((item, idx) => (
          <div key={idx} className="text-center">
            <div className="w-20 h-20 rounded-full bg-acqua/20 flex items-center justify-center mx-auto mb-6">
              <item.icon className="w-10 h-10 text-acqua" />
            </div>
            <h4 className="text-xl font-semibold text-papiro mb-3">{item.title}</h4>
            <p className="text-muted-foreground">{item.desc}</p>
          </div>
        ))}
      </div>
      
      <div className="bg-card rounded-xl p-8 border border-acqua/30">
        <h4 className="text-2xl font-semibold text-papiro mb-6 text-center">
          La Svolta Industriale
        </h4>
        <p className="text-lg text-muted-foreground leading-relaxed text-center max-w-3xl mx-auto">
          Con la <strong className="text-acqua">rivoluzione industriale</strong>, 
          la bonifica entra nell'era moderna. Le pompe a vapore, poi elettriche, 
          permettono di drenare aree prima inaccessibili. I progetti si fanno 
          sempre più ambiziosi, trasformando intere regioni.
        </p>
      </div>
    </Section>
  );
}

// Fascismo Section
function FascismoSection() {
  const aspects = [
    { title: "Bonifica idraulica", desc: "Canali, argini e drenaggio" },
    { title: "Bonifica agraria", desc: "Preparazione del suolo per l'agricoltura" },
    { title: "Bonifica sanitaria", desc: "Lotta alla malaria e alle malattie" },
    { title: "Bonifica sociale", desc: "Insediamento di coloni e costruzione di città" },
  ];

  const cities = ["Littoria (Latina)", "Sabaudia", "Aprilia", "Pontinia"];

  return (
    <Section id="fascismo" title="Il Caso del Fascismo" subtitle="Bonifica Integrale">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-terra/30 shadow-2xl">
        <img 
          src="/images/fascismo-agro-pontino.jpg" 
          alt="Bonifica dell'Agro Pontino"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">La bonifica dell'Agro Pontino diventa simbolo del regime</p>
        </div>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-12 mb-16">
        <div>
          <p className="text-lg leading-relaxed mb-6">
            Durante il regime fascista, la bonifica diventa anche 
            <strong className="text-terra"> propaganda politica</strong>. 
            Nasce il concetto di <strong className="text-sabbia">bonifica integrale</strong>, 
            che unisce interventi idraulici, agricoli, sanitari e sociali.
          </p>
          
          <p className="text-lg leading-relaxed mb-8">
            La più celebre è la bonifica dell'<strong className="text-sabbia">Agro Pontino</strong>, 
            che trasformò una vasta palude malarica in una delle zone agricole 
            più produttive d'Italia.
          </p>
          
          <div className="bg-terra/10 rounded-lg p-6 border border-terra/30">
            <h5 className="font-semibold text-papiro mb-4">Nuove città fondate:</h5>
            <div className="flex flex-wrap gap-2">
              {cities.map((city, idx) => (
                <span 
                  key={idx} 
                  className="px-3 py-1 bg-terra/30 rounded-full text-sm text-papiro"
                >
                  {city}
                </span>
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {aspects.map((aspect, idx) => (
            <Card key={idx} className="bg-card/80 border-terra/30">
              <CardContent className="p-5">
                <div className="w-8 h-8 rounded-full bg-terra/20 flex items-center justify-center mb-3">
                  <span className="text-sabbia text-sm font-bold">{idx + 1}</span>
                </div>
                <h5 className="font-semibold text-papiro mb-2">{aspect.title}</h5>
                <p className="text-sm text-muted-foreground">{aspect.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-terra/20 via-sabbia/10 to-terra/20 rounded-xl p-8 text-center">
        <p className="text-xl text-muted-foreground italic max-w-3xl mx-auto">
          "Qui la bonifica non è solo idraulica, ma un progetto totale 
          che mira a trasformare uomini e territorio."
        </p>
      </div>
    </Section>
  );
}

// Dopoguerra Section
function DopoguerraSection() {
  const evolution = [
    { 
      era: "Dopo il 1945", 
      focus: "Agricoltura e difesa del suolo",
      desc: "La bonifica continua per sostenere l'agricoltura e proteggere il territorio"
    },
    { 
      era: "Ultimi decenni", 
      focus: "Valore ecologico",
      desc: "Si riconosce l'importanza delle zone umide per l'ecosistema"
    },
    { 
      era: "Oggi", 
      focus: "Gestione sostenibile",
      desc: "Non più solo 'prosciugare', ma gestire l'acqua in equilibrio con la natura"
    },
  ];

  return (
    <Section id="dopoguerra" title="Ripensare la Bonifica" subtitle="Dal Dopoguerra a Oggi" bgGradient="water">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-acqua/30 shadow-2xl">
        <img 
          src="/images/oggi-sostenibilita.jpg" 
          alt="Gestione sostenibile delle zone umide"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">Oggi la bonifica cerca l'equilibrio tra agricoltura e natura</p>
        </div>
      </div>
      
      <div className="mb-16">
        <div className="flex flex-col lg:flex-row items-center gap-8 mb-12">
          <div className="flex-1">
            <h4 className="text-2xl font-semibold text-papiro mb-4">Un Cambio di Prospettiva</h4>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              Negli ultimi decenni, la concezione della bonifica è profondamente cambiata. 
              Dalla <strong className="text-acqua">lotta contro la natura</strong> si è 
              passati alla <strong className="text-green-500">gestione consapevole</strong> del territorio.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Oggi si riconosce il <strong>valore ecologico delle zone umide</strong>, 
              fondamentali per la biodiversità e l'equilibrio ambientale.
            </p>
          </div>
          <div className="flex-1 flex justify-center">
            <div className="relative">
              <div className="w-48 h-48 rounded-full bg-gradient-to-br from-acqua to-green-600 flex items-center justify-center">
                <Leaf className="w-24 h-24 text-papiro" />
              </div>
              <div className="absolute -top-4 -right-4 w-16 h-16 rounded-full bg-green-500 flex items-center justify-center">
                <Droplets className="w-8 h-8 text-papiro" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-6">
        {evolution.map((item, idx) => (
          <div 
            key={idx}
            className="flex items-center gap-6 p-6 bg-card/50 rounded-xl border border-border hover:border-acqua/50 transition-all"
          >
            <div className="w-16 h-16 rounded-full bg-acqua/20 flex items-center justify-center flex-shrink-0">
              <span className="text-acqua font-bold text-lg">{idx + 1}</span>
            </div>
            <div className="flex-1">
              <span className="text-sabbia text-sm font-semibold">{item.era}</span>
              <h5 className="text-xl font-semibold text-papiro mb-1">{item.focus}</h5>
              <p className="text-muted-foreground">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <div className="inline-flex items-center gap-4 px-8 py-4 bg-gradient-to-r from-acqua/20 to-green-500/20 rounded-full border border-acqua/30">
          <span className="text-muted-foreground">Lotta contro la natura</span>
          <ArrowDown className="w-5 h-5 text-sabbia rotate-90" />
          <span className="text-green-400 font-semibold">Equilibrio con l'ambiente</span>
        </div>
      </div>
    </Section>
  );
}

// Emilia Section
function EmiliaSection() {
  const steps = [
    {
      num: "1",
      title: "Un territorio 'contro' l'uomo",
      content: "L'Emilia era bassa e pianeggiante, attraversata da fiumi instabili (Po, Reno, Secchia, Panaro) che straripavano spesso, rendendo la terra improduttiva, malsana e difficile da abitare."
    },
    {
      num: "2",
      title: "I Romani: il punto di partenza",
      content: "Con la centuriazione, i canali di scolo, gli argini e la regolazione dei corsi d'acqua, i Romani rendono coltivabile la pianura e garantiscono strade, città e commerci lungo la via Emilia."
    },
    {
      num: "3",
      title: "Dopo i Romani: il rischio di tornare palude",
      content: "Con la fine dell'Impero, le opere non vengono più mantenute, i fiumi riprendono il sopravvento e molte aree tornano paludose."
    },
    {
      num: "4",
      title: "La bonifica 'dal basso'",
      content: "Monasteri, comunità contadine e comuni capiscono che 'se non si lavora insieme, l'acqua vince'. Nascono canali scavati collettivamente, regole comuni e prime forme di gestione condivisa."
    },
    {
      num: "5",
      title: "Da qui in poi",
      content: "Da questa base nascono le Partecipanze agrarie, i consorzi di bonifica e l'idea che la terra va 'costruita' e mantenuta nel tempo attraverso cooperazione e responsabilità collettiva."
    },
  ];

  return (
    <Section id="emilia" title="La Bonifica in Emilia" subtitle="Storia Locale">
      {/* Immagine */}
      <div className="mb-12 rounded-2xl overflow-hidden border border-terra/30 shadow-2xl">
        <img 
          src="/images/emilia-campagna.jpg" 
          alt="Campagna emiliana con canali"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="bg-card/80 p-4 text-center">
          <p className="text-sm text-muted-foreground">La campagna emiliana: il risultato di secoli di bonifica</p>
        </div>
      </div>
      
      <div className="mb-12">
        <p className="text-xl text-center text-muted-foreground max-w-3xl mx-auto">
          Come nasce davvero la bonifica in una delle regioni simbolo 
          della trasformazione del territorio italiano.
        </p>
      </div>
      
      <div className="space-y-8">
        {steps.map((step, idx) => (
          <div 
            key={idx}
            className="flex gap-6 p-6 bg-card/50 rounded-xl border border-terra/30 hover:border-terra transition-all"
          >
            <div className="flex-shrink-0">
              <div className="w-14 h-14 rounded-full bg-terra flex items-center justify-center">
                <span className="text-papiro text-xl font-bold">{step.num}</span>
              </div>
              {idx < steps.length - 1 && (
                <div className="w-0.5 h-12 bg-terra/30 mx-auto mt-4" />
              )}
            </div>
            <div className="flex-1 pt-2">
              <h4 className="text-xl font-semibold text-papiro mb-3">{step.title}</h4>
              <p className="text-muted-foreground leading-relaxed">{step.content}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12 bg-gradient-to-r from-terra/20 to-acqua/20 rounded-xl p-8 text-center border border-terra/30">
        <MapPin className="w-12 h-12 text-sabbia mx-auto mb-4" />
        <h4 className="text-2xl font-semibold text-papiro mb-4">La Radice Emiliana</h4>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          La bonifica in Emilia nasce quando le comunità capiscono che per abitare 
          la pianura bisogna <strong className="text-sabbia">governare l'acqua insieme, ogni giorno</strong>.
        </p>
      </div>
    </Section>
  );
}

// Navigation
function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const navItems = [
    { id: 'antichita', label: 'Antichità' },
    { id: 'medioevo', label: 'Medioevo' },
    { id: 'eta-moderna', label: 'Età Moderna' },
    { id: 'ottocento-novecento', label: 'Ottocento' },
    { id: 'fascismo', label: 'Fascismo' },
    { id: 'dopoguerra', label: 'Oggi' },
    { id: 'emilia', label: 'Emilia' },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-notte/95 backdrop-blur-md py-3 shadow-lg' : 'py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-sabbia font-semibold text-lg hover:text-papiro transition-colors"
          >
            La Bonifica
          </button>
          
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="px-3 py-2 text-sm text-muted-foreground hover:text-papiro hover:bg-terra/20 rounded-lg transition-all"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}

// Footer
function Footer() {
  return (
    <footer className="bg-notte border-t border-terra/30 py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-papiro mb-4">La Storia della Bonifica</h3>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Un viaggio attraverso i secoli per scoprire come l'uomo ha imparato 
            a convivere con l'acqua, dalla lotta alla collaborazione.
          </p>
        </div>
        
        <Separator className="bg-terra/30 mb-8" />
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>Dagli inizi fino ai giorni nostri</p>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2">
              <Landmark className="w-4 h-4" />
              Romani
            </span>
            <span className="flex items-center gap-2">
              <Factory className="w-4 h-4" />
              Industrializzazione
            </span>
            <span className="flex items-center gap-2">
              <Leaf className="w-4 h-4" />
              Sostenibilità
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Main App
function App() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <Hero />
      <AntichitaSection />
      <MedioevoSection />
      <EtaModernaSection />
      <OttocentoNovecentoSection />
      <FascismoSection />
      <DopoguerraSection />
      <EmiliaSection />
      <Footer />
    </div>
  );
}

export default App;
